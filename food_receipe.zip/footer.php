<hr>
   <div class="container">
   <h5 class="text-dark">Gallery</h5> 
   </div>
   <div class="card-group mt-4">
    <div class="card">
        <img src="assets/images/f1.jfif" style="height:200px;" class="card-img-top">
       
    </div>
    <div class="card">
        <img src="assets/images/f2.jfif" style="height:200px;" class="card-img-top">
       
    </div>
    <div class="card">
        <img src="assets/images/f3.jfif" style="height:200px;">
       
    </div>
    <div class="card">
        <img src="assets/images/f4.jfif" style="height:200px;">
       
    </div>
    <div class="card">
        <img src="assets/images/f5.jfif" style="height:200px;">
       
    </div>
    <div class="card">
        <img src="assets/images/f6.jfif" style="height:200px;">
       
    </div>
    <div class="card">
        <img src="assets/images/f7.jfif" style="height:200px;">
       
    </div>
    
   </div>
   <div class="container py-4">
    <div class="row small text-secondary font-weight-bold">
        <div class="col-md-4">
                <p>
                <i class="fa-brands fa-facebook"></i>
                <i class="fa-brands fa-google-plus-g ml-2"></i>
                <i class="fa-brands fa-instagram ml-2"></i>
                <i class="fa-brands fa-twitter ml-2"></i>
                <i class="fa-brands fa-youtube ml-2"></i>
                <i class="fa-brands fa-linkedin-in ml-2"></i>
                </p>
            
        </div>
        <div class="col-md-4">
            <p class="text-center">
            &copy; <?=date('Y')?> Copyrights reserved.
            </p>
        </div>
        <div class="col-md-4">
            <p class="text-right">
            Food receipe system portal
            </p>
        </div>
    </div>
   </div>